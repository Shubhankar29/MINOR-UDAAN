India, with about 2.1% of specially-abled people and about 2 crores of bright unexplored brains which have billions of blooming ideas and an ocean of unexplored talent. If these are the numbers, then why are the opportunities available for all our specially-abled friends not reaching them? This was the question that gave birth to UDAAN. 

The major problem identified by us was the absence of interactivity and accessibility to the websites present on the web. The government websites which are present are extremely difficult to code. That's where our online portal UDAAN comes and bridges this gap. 

Udaan is an all-in-one platform that helps you explore all sorts of opportunities for the specially-abled like jobs, scholarships, skill up-gradation courses, various NGOs. We not only focus on providing the opportunities and help but are also determined to encourage our specially-abled friends by sharing with them the success stories of common people under our Hero page. 

To make our website more user-friendly for visually impaired people we have also added VOICE CONTROLLED NAVIGATION and AUTO READ feature. 

Smile on the face and pride in the eyes of all our specially-abled friends is the mission and vision of UDAAN.